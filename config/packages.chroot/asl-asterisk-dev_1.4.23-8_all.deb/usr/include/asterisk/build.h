/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "raspberrypi"
#define BUILD_KERNEL "5.10.11-v7l+"
#define BUILD_MACHINE "armv7l"
#define BUILD_OS "Linux"
#define BUILD_DATE "2021-03-24 18:08:36 UTC"
#define BUILD_USER ""

