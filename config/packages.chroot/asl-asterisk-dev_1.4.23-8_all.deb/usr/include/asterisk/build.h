/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "Rick"
#define BUILD_KERNEL "4.19.0-14-amd64"
#define BUILD_MACHINE "x86_64"
#define BUILD_OS "Linux"
#define BUILD_DATE "2021-03-04 03:22:56 UTC"
#define BUILD_USER ""

