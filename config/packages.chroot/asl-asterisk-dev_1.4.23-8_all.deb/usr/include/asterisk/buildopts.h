/*
 * buildopts.h 
 * Automatically generated
 */

#define LOADABLE_MODULES 1
#define AST_BUILDOPT_SUM "f450f61f60e761b3aa089ebed76ca8a5"
