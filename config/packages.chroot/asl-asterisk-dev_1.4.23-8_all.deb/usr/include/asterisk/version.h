/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "GIT Version 846efd0"
#define ASTERISK_VERSION_NUM 

