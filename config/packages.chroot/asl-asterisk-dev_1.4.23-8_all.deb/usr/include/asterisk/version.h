/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "GIT a4245fb"
#define ASTERISK_VERSION_HTTP "AllStarClient/GIT a4245fb"
#define ASTERISK_VERSION_NUM 

