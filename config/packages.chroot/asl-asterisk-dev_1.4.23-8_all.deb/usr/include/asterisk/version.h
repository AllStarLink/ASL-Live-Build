/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "GIT 6a9b0c6"
#define ASTERISK_VERSION_HTTP "AllStarClient/GIT 6a9b0c6"
#define ASTERISK_VERSION_NUM 

