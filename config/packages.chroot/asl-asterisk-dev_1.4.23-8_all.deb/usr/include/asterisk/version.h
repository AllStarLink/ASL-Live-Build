/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "GIT Version d22d7e0"
#define ASTERISK_VERSION_NUM 

